import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Load .env from project root
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const envPath = path.resolve(__dirname, '../.env');
dotenv.config({ path: envPath });

console.log('--- Email Verification Script ---');
console.log(`SMTP_HOST: ${process.env.SMTP_HOST}`);
console.log(`SMTP_PORT: ${process.env.SMTP_PORT}`);
console.log(`SMTP_USER: ${process.env.SMTP_USER}`);

if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
    console.error('ERROR: Missing SMTP credentials in .env file.');
    process.exit(1);
}

const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    secure: false,
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
    }
});

async function verifyAndSend() {
    try {
        // 1. Verify Connection
        console.log('Verifying SMTP connection...');
        await transporter.verify();
        console.log('✅ Connection verified successfully!');

        // 2. Send Test Email
        console.log('Sending test email...');
        const info = await transporter.sendMail({
            from: `"Test Script" <${process.env.SMTP_USER}>`,
            to: process.env.SMTP_USER, // Send to self
            subject: 'ADZ4NEEDZ Email Configuration Test',
            text: 'If you receive this, your email configuration works!',
            html: '<b>If you receive this, your email configuration works!</b>'
        });

        console.log('✅ Test email sent!');
        console.log(`Message ID: ${info.messageId}`);
    } catch (error) {
        console.error('❌ Error during verification:', error);
    }
}

verifyAndSend();
