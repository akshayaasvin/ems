import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';
import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 5000;

app.use(cors());
app.use(bodyParser.json());

// Path to data file
const DATA_FILE = path.join(__dirname, 'data', 'users.json');

// Ensure data file exists
if (!fs.existsSync(DATA_FILE)) {
    fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
    fs.writeFileSync(DATA_FILE, '[]');
}

// Helper to read users
const getUsers = () => {
    try {
        const data = fs.readFileSync(DATA_FILE, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        console.error("Error reading users:", err);
        return [];
    }
};

// Helper to save users
const saveUsers = (users) => {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(users, null, 2));
    } catch (err) {
        console.error("Error saving users:", err);
    }
};

// --- EMAIL CONFIGURATION ---
// For development, we use a simple console logger if no credentials.
// In production, use real credentials from .env
const transporter = nodemailer.createTransport({
    // Example: Gmail or Ethereal
    host: process.env.SMTP_HOST || 'smtp.ethereal.email',
    port: process.env.SMTP_PORT || 587,
    secure: false, // true for 465, false for other ports
    auth: {
        user: process.env.SMTP_USER || 'ethereal_user',
        pass: process.env.SMTP_PASS || 'ethereal_pass'
    }
});

// --- ROUTES ---

// 1. Register Endpoint
app.post('/api/register', async (req, res) => {
    const { fullName, email, phone, password, role, department } = req.body;

    // Validation
    if (!email || !password || !fullName) {
        return res.status(400).json({ success: false, message: 'Missing required fields.' });
    }

    // Email format
    const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailRegex.test(email)) {
        return res.status(400).json({ success: false, message: 'Invalid email format.' });
    }

    // Password strength (Simple check: length > 6)
    if (password.length < 6) {
        return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    }

    const users = getUsers();

    // Check duplicate
    if (users.find(u => u.email === email)) {
        return res.status(400).json({ success: false, message: 'Email already registered.' });
    }

    // Generate Unique ID: ADZ + 6 random digits
    let newId;
    let isUnique = false;
    while (!isUnique) {
        const randomDigits = Math.floor(100000 + Math.random() * 900000); // 6 digits
        newId = `ADZ${randomDigits}`;
        if (!users.find(u => u.id === newId)) {
            isUnique = true;
        }
    }

    // Hash Password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create User
    const newUser = {
        id: newId,
        fullName,
        email,
        phone,
        password: hashedPassword, // Store hashed
        role,
        department,
        createdAt: new Date().toISOString()
    };

    users.push(newUser);
    saveUsers(users);

    // Send Email
    // Note: In a real app, use a background job/queue. Here we await for simplicity or fire-and-forget.
    const mailOptions = {
        from: '"ADZ4NEEDZ" <noreply@adz4needz.com>',
        to: email,
        subject: 'Welcome to ADZ4NEEDZ',
        text: `Welcome to ADZ4NEEDZ\n\nYour credentials Employee ID is : ${newId}\n\nLet's connect\n\nRegards,\nadz4needz`,
        html: `
            <h3>Welcome to ADZ4NEEDZ</h3>
            <p>Your credentials Employee ID is : <b>${newId}</b></p>
            <p>Let's connect</p>
            <br/>
            <p>Regards,<br/>adz4needz</p>
        `
    };

    try {
        console.log(`[Mock Email] Sending to ${email} with ID ${newId}...`);
        // If no real creds, this might fail or just log.
        // We'll wrap in try/catch to not block registration success if email fails (Requirement says: log error but don't delete account)
        if (process.env.SMTP_HOST) {
            const info = await transporter.sendMail(mailOptions);
            console.log("Message sent: %s", info.messageId);
        } else {
            console.log("No SMTP_HOST set. Verification email simulated.");
            console.log(`SUBJECT: ${mailOptions.subject}`);
            console.log(`BODY: ${mailOptions.text}`);
        }
    } catch (error) {
        console.error("Error sending email:", error);
        // Requirement: "System should log the error. Registration should still exist."
    }

    res.json({ success: true, id: newId, message: 'User registered successfully. check email for ID.' });
});

// 2. Login Endpoint
app.post('/api/login', async (req, res) => {
    const { employeeId, password } = req.body;

    const users = getUsers();
    const user = users.find(u => u.id === employeeId);

    if (!user) {
        return res.status(401).json({ success: false, message: 'Invalid Employee ID or Password.' });
    }

    // Compare Hash
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
        return res.status(401).json({ success: false, message: 'Invalid Employee ID or Password.' });
    }

    // Return user info (excluding password)
    const { password: _, ...userWithoutPass } = user;
    res.json({ success: true, user: userWithoutPass });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
