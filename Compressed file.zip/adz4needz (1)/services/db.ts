import { User, Task, Submission, Attendance, Role, ClassSession, StoredFile, Department } from '../types';

const KEYS = {
  USERS: 'adz_users',
  TASKS: 'adz_tasks',
  SUBMISSIONS: 'adz_submissions',
  ATTENDANCE: 'adz_attendance',
  SESSIONS: 'adz_sessions',
  CURRENT_USER: 'adz_current_user'
};

// Mock AppSettings for "Backend" simulation
const EMAIL_SETTINGS = {
  SmtpServer: "smtp.gmail.com",
  Port: 587,
  SenderEmail: "admin@adz4needz.com"
};

// --- Helpers ---

const get = <T>(key: string, defaultValue: T): T => {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : defaultValue;
  } catch (e) {
    console.error("Storage Error", e);
    return defaultValue;
  }
};

const set = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e: any) {
    console.error("Storage Set Error", e);
    if (e.name === 'QuotaExceededError') {
      alert("Storage Full! Cannot save file. Please clear some old data or use smaller files.");
    }
  }
};

const formatTimeFromISO = (isoString: string): string => {
  if (!isoString) return '';
  try {
    if (!isoString.includes('T') && isoString.includes(':')) return isoString;
    return new Date(isoString).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
  } catch (e) {
    return isoString;
  }
};

export const readFileAsBase64 = (file: File): Promise<StoredFile> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      resolve({
        name: file.name,
        type: file.type,
        content: reader.result as string
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

// --- Users & Auth (Simulated Backend) ---

export const getUsers = (): User[] => get<User[]>(KEYS.USERS, []);

export const findUserByEmail = (email: string): User | undefined => {
  return getUsers().find(u => u.email === email);
};

export const findUserById = (id: string): User | undefined => {
  return getUsers().find(u => u.id === id);
};

/**
 * Simulates a backend endpoint: /api/register
 * 1. Generates ID
 * 2. Saves User
 * 3. Sends Email (Simulated Delay)
 */
export const registerUserWithEmailNotification = async (
  name: string,
  email: string,
  phone: string,
  pass: string,
  role: Role,
  dept: Department
): Promise<{ success: boolean; id?: string; message?: string }> => {

  // Simulate Network/Processing Delay
  await new Promise(resolve => setTimeout(resolve, 2000));

  const users = getUsers();
  if (users.find(u => u.email === email)) {
    return { success: false, message: 'Email already exists.' };
  }

  // Generate Backend ID
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const prefix = role === Role.INTERN ? 'ADZ-INT' : role === Role.EMPLOYEE ? 'ADZ-EMP' : 'ADZ-TEL';
  const newId = `${prefix}-${randomSuffix}`;

  const newUser: User = {
    id: newId,
    fullName: name,
    email: email,
    password: pass,
    phone: phone,
    role: role,
    department: role === Role.INTERN ? dept : (role === Role.TELECALLER ? Department.TELECALLER : Department.NONE),
    createdAt: new Date().toISOString()
  };

  // Save to DB
  users.push(newUser);
  set(KEYS.USERS, users);

  // Simulate SMTP Send
  console.log(`[SMTP MOCK] Connecting to ${EMAIL_SETTINGS.SmtpServer}...`);
  console.log(`[SMTP MOCK] Sending email to ${email} from ${EMAIL_SETTINGS.SenderEmail}`);
  console.log(`[SMTP MOCK] Subject: Welcome to ADZ4NEEDZ - Here is your Employee ID`);
  console.log(`[SMTP MOCK] Body: Hello ${name}, your Employee ID is: ${newId}. Please login with your password.`);

  return { success: true, id: newId };
};

/**
 * Manually saves a user to LocalStorage (used to sync after Real Backend registration)
 */
export const syncUserToLocal = (user: User): void => {
  const users = getUsers();
  if (!users.find(u => u.id === user.id)) {
    users.push(user);
    set(KEYS.USERS, users);
    console.log(`[Sync] User ${user.id} synced to local storage.`);
  }
};

// --- Tasks ---

export const getTasks = (): Task[] => get<Task[]>(KEYS.TASKS, []);

export const addTask = (task: Task): void => {
  const tasks = getTasks();
  tasks.push(task);
  set(KEYS.TASKS, tasks);
};

export const updateTask = (updatedTask: Task): void => {
  const tasks = getTasks().map(t => t.id === updatedTask.id ? updatedTask : t);
  set(KEYS.TASKS, tasks);
};

export const deleteTask = (taskId: string): void => {
  console.log(`Deleting task ${taskId}...`);
  // 1. Get fresh state
  const currentTasks = getTasks();
  // 2. Filter
  const newTasks = currentTasks.filter(t => t.id !== taskId);
  // 3. Save immediately
  set(KEYS.TASKS, newTasks);

  // 4. Cascade delete submissions
  const currentSubmissions = getSubmissions();
  const newSubmissions = currentSubmissions.filter(s => s.taskId !== taskId);
  set(KEYS.SUBMISSIONS, newSubmissions);
  console.log(`Task ${taskId} deleted. Remaining tasks: ${newTasks.length}`);
};

// --- Class Sessions (Notes) ---

export const getClassSessions = (): ClassSession[] => get<ClassSession[]>(KEYS.SESSIONS, []);

export const addClassSession = (session: ClassSession): void => {
  const sessions = getClassSessions();
  sessions.push(session);
  set(KEYS.SESSIONS, sessions);
};

export const deleteClassSession = (sessionId: string): void => {
  const sessions = getClassSessions().filter(s => s.id !== sessionId);
  set(KEYS.SESSIONS, sessions);
};

// --- Submissions ---

export const getSubmissions = (): Submission[] => get<Submission[]>(KEYS.SUBMISSIONS, []);

export const addSubmission = (submission: Submission): void => {
  const submissions = getSubmissions();
  const filtered = submissions.filter(s => !(s.taskId === submission.taskId && s.userId === submission.userId));
  filtered.push(submission);
  set(KEYS.SUBMISSIONS, filtered);
};

// --- Attendance ---

export const getAttendance = (): Attendance[] => get<Attendance[]>(KEYS.ATTENDANCE, []);

export const markAttendance = (attendance: Attendance): void => {
  const list = getAttendance();
  list.push(attendance);
  set(KEYS.ATTENDANCE, list);
};

export const getTodayAttendance = (userId: string): Attendance | undefined => {
  const today = new Date().toISOString().split('T')[0];
  return getAttendance().find(a => a.userId === userId && a.date === today);
};

// --- Auth Session ---

export const loginUser = (user: User): void => {
  localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify(user));
};

export const logoutUser = (): void => {
  localStorage.removeItem(KEYS.CURRENT_USER);
};

export const getCurrentUser = (): User | null => {
  const stored = localStorage.getItem(KEYS.CURRENT_USER);
  return stored ? JSON.parse(stored) : null;
};

// --- Export to "Excel" (CSV) ---

export const exportDataToCSV = (startDate?: string, endDate?: string) => {
  const users = getUsers();
  const tasks = getTasks();
  const submissions = getSubmissions();
  const attendance = getAttendance();

  // --- 1. User Registry & Performance Report ---
  const userHeader = ['Employee ID', 'Full Name', 'Email', 'Phone', 'Role', 'Department', 'Join Date', 'Total Days', 'Days Present', 'Attendance %', 'Tasks Assigned', 'Tasks Submitted', 'Performance %'];

  const userRows = users.map(u => {
    // Calculate Attendance
    const joinDate = u.createdAt ? new Date(u.createdAt) : new Date('2024-01-01'); // Fallback if missing
    const today = new Date();
    const timeDiff = today.getTime() - joinDate.getTime();
    const totalDays = Math.max(1, Math.floor(timeDiff / (1000 * 3600 * 24))); // Avoid division by zero

    const userAttendance = attendance.filter(a => a.userId === u.id);
    const daysPresent = userAttendance.length;
    const attendancePct = ((daysPresent / totalDays) * 100).toFixed(1);

    // Calculate Performance
    const userTasks = tasks.filter(t => {
      const roleMatch = !t.assignedToRole || t.assignedToRole === u.role;
      const deptMatch = !t.assignedToDepartment || t.assignedToDepartment === u.department;
      return roleMatch && deptMatch;
    });
    const totalAssigned = userTasks.length;

    const userSubmissions = submissions.filter(s => s.userId === u.id);
    const submittedCount = userSubmissions.length;

    const performancePct = totalAssigned > 0
      ? ((submittedCount / totalAssigned) * 100).toFixed(1)
      : '0.0';

    return [
      u.id,
      `"${u.fullName}"`,
      u.email,
      u.phone,
      u.role,
      u.department,
      u.createdAt || '-',
      totalDays,
      daysPresent,
      `${attendancePct}%`,
      totalAssigned,
      submittedCount,
      `${performancePct}%`
    ].join(',');
  });

  const userCsvContent = [userHeader.join(','), ...userRows].join('\n');

  downloadBlob(userCsvContent, `ADZ_Performance_Report_${new Date().toISOString().split('T')[0]}.csv`, 'text/csv');

  const reportHeader = ['Date', 'Task ID', 'Task Title', 'Employee ID', 'Employee Name', 'Attendance Status', 'Clock In Time', 'Submission Content', 'Submitted At', 'Submission Status'];

  const reportRows: string[] = [];
  const sortedAttendance = attendance.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  sortedAttendance.forEach(att => {
    if (startDate && att.date < startDate) return;
    if (endDate && att.date > endDate) return;

    const user = users.find(u => u.id === att.userId);
    if (!user) return;

    const clockInDisplay = formatTimeFromISO(att.clockInTime);

    const userTasks = tasks.filter(t =>
      t.date === att.date &&
      (t.assignedToRole === user.role || !t.assignedToRole) &&
      (t.assignedToDepartment === user.department || !t.assignedToDepartment)
    );

    if (userTasks.length === 0) {
      reportRows.push([att.date, 'N/A', 'No Task Assigned', user.id, `"${user.fullName}"`, att.status, clockInDisplay, 'N/A', 'N/A', 'N/A'].join(','));
    } else {
      userTasks.forEach(task => {
        const sub = submissions.find(s => s.taskId === task.id && s.userId === user.id);
        let content = 'Pending';
        if (sub) {
          if (sub.content) content = sub.content;
          else if (sub.files && sub.files.length > 0) content = `${sub.files.length} Files Attached`;
          else if (sub.fileUrl) content = 'Files Attached (Legacy)';
        }
        const submittedAtDisplay = sub ? formatTimeFromISO(sub.submittedAt) : '';

        reportRows.push([
          att.date,
          task.id,
          `"${task.title.replace(/"/g, '""')}"`,
          user.id,
          `"${user.fullName}"`,
          att.status,
          clockInDisplay,
          `"${content.replace(/"/g, '""')}"`,
          submittedAtDisplay,
          sub ? sub.status : 'PENDING'
        ].join(','));
      });
    }
  });

  if (reportRows.length === 0) {
    reportRows.push('No activity found for the selected range.,,,,,,,,,');
  }

  const activityCsvContent = [reportHeader.join(','), ...reportRows].join('\n');
  const now = new Date();
  const timeStr = `${now.getHours()}-${now.getMinutes()}-${now.getSeconds()}`;
  const filename = `ADZ_Activity_Report_${startDate || 'All'}_to_${endDate || 'All'}_${timeStr}.csv`;

  setTimeout(() => downloadBlob(activityCsvContent, filename, 'text/csv'), 500);
};

const downloadBlob = (content: string, filename: string, contentType: string) => {
  const blob = new Blob([content], { type: contentType });
  const url = URL.createObjectURL(blob);
  const pom = document.createElement('a');
  pom.href = url;
  pom.setAttribute('download', filename);
  pom.click();
};