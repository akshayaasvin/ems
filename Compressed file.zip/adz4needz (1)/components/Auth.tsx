import React, { useState } from 'react';
import { User, Role, Department, ROLES, DEPARTMENTS } from '../types';
import { loginUser, syncUserToLocal } from '../services/db';
import { User as UserIcon, Lock, ChevronLeft, ShieldCheck, KeyRound, Mail, Loader2, Info, CircuitBoard } from 'lucide-react';

interface AuthProps {
  onLogin: (user: User) => void;
}

// --- Custom Logo Component ---
const Logo = ({ className = "" }: { className?: string }) => (
  <div className={`flex items-center gap-3 ${className}`}>
    {/* Custom SVG Logo matching the user's blue microchip image */}
    <div className="relative w-16 h-16 flex items-center justify-center">
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-lg" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#06b6d4" /> {/* Cyan-500 */}
            <stop offset="100%" stopColor="#2563eb" /> {/* Blue-600 */}
          </linearGradient>
        </defs>

        {/* Pins (3 on each side) */}
        {/* Top Pins */}
        <path d="M35 15V5 M50 15V5 M65 15V5" stroke="url(#logoGradient)" strokeWidth="6" strokeLinecap="round" />
        {/* Bottom Pins */}
        <path d="M35 85V95 M50 85V95 M65 85V95" stroke="url(#logoGradient)" strokeWidth="6" strokeLinecap="round" />
        {/* Left Pins */}
        <path d="M15 35H5 M15 50H5 M15 65H5" stroke="url(#logoGradient)" strokeWidth="6" strokeLinecap="round" />
        {/* Right Pins */}
        <path d="M85 35H95 M85 50H95 M85 65H95" stroke="url(#logoGradient)" strokeWidth="6" strokeLinecap="round" />

        {/* Main Chip Body */}
        <rect x="20" y="20" width="60" height="60" rx="10" stroke="url(#logoGradient)" strokeWidth="5" fill="white" />

        {/* Inner Circuit Detail (Stylized "G" / Circuit shape) */}
        <path d="M60 40H45C42.2386 40 40 42.2386 40 45V55C40 57.7614 42.2386 60 45 60H60" stroke="url(#logoGradient)" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M60 50H52" stroke="url(#logoGradient)" strokeWidth="5" strokeLinecap="round" />
      </svg>
    </div>
    <div className="flex flex-col">
      <h1 className="text-3xl font-black tracking-tight text-cyan-600 leading-none">
        ADZ<span className="text-blue-600">4</span>NEEDZ
      </h1>
      <span className="text-[10px] font-bold tracking-[0.2em] text-gray-400 uppercase mt-1">
        Your Trusted Digital Partner
      </span>
    </div>
  </div>
);

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [view, setView] = useState<'LOGIN' | 'REGISTER' | 'FORGOT' | 'EMAIL_SENT'>('LOGIN');
  const [isAdminLogin, setIsAdminLogin] = useState(false);
  const [error, setError] = useState('');

  // Login State
  const [loginId, setLoginId] = useState('');
  const [loginName, setLoginName] = useState('');
  const [loginPass, setLoginPass] = useState('');

  // Register State
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regConfirmPass, setRegConfirmPass] = useState('');
  const [regRole, setRegRole] = useState<Role>(Role.INTERN);
  const [regDept, setRegDept] = useState<Department>(Department.HR);

  const [isRegistering, setIsRegistering] = useState(false);
  const [generatedId, setGeneratedId] = useState<string | null>(null);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const pinCode = loginPass.trim();
    if (pinCode.length !== 4 || isNaN(Number(pinCode))) {
      setError('Please enter a valid 4-digit PIN.');
      return;
    }

    const internalPassword = `/admin${pinCode}`;
    const correctPassword = `/admin3456`;

    if (internalPassword === correctPassword) {
      const adminUser: User = {
        id: 'ADZ-ADMIN',
        fullName: loginName || 'Super Admin',
        email: 'admin@adz4needz.com',
        password: internalPassword,
        phone: '0000000000',
        role: Role.MENTOR,
        department: Department.NONE
      };
      loginUser(adminUser);
      onLogin(adminUser);
    } else {
      setError('Invalid Access PIN.');
    }
  };

  const handleEmployeeLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const response = await fetch('http://localhost:5000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employeeId: loginId.trim(), password: loginPass })
      });
      const data = await response.json();

      if (data.success && data.user) {
        loginUser(data.user);
        onLogin(data.user);
      } else {
        setError(data.message || 'Invalid Employee ID or Password');
      }
    } catch (err) {
      console.error("Login Error:", err);
      setError('Server connection failed. Ensure backend is running.');
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (regPass !== regConfirmPass) { setError('Passwords do not match.'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(regEmail)) { setError('Invalid Email format.'); return; }
    if (!/^\d{10}$/.test(regPhone)) { setError('Phone number must be 10 digits.'); return; }

    setIsRegistering(true);

    try {
      const response = await fetch('http://localhost:5000/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: regName, email: regEmail, phone: regPhone, password: regPass, role: regRole, department: regDept
        })
      });
      const result = await response.json();

      if (result.success && result.id) {
        syncUserToLocal({
          id: result.id,
          fullName: regName,
          email: regEmail,
          password: regPass,
          phone: regPhone,
          role: regRole,
          department: regRole === Role.INTERN ? regDept : (regRole === Role.TELECALLER ? Department.TELECALLER : Department.NONE),
          createdAt: new Date().toISOString()
        });
        setGeneratedId(result.id);
        setView('EMAIL_SENT');
        setRegName(''); setRegPhone(''); setRegPass(''); setRegConfirmPass('');
      } else {
        setError(result.message || 'Registration failed.');
      }
    } catch (err) {
      setError('System error. Server might be offline.');
    } finally {
      setIsRegistering(false);
    }
  };

  const handleForgot = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Simulation: Password reset link sent.');
    setView('LOGIN');
  };

  // --- Styles & Effects ---
  const glassCardClass = "bg-white/90 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/50 w-full max-w-md p-8 relative overflow-hidden transition-all duration-500 animate-fade-in";
  const inputClass = "w-full bg-gray-50/50 border border-gray-200 rounded-xl p-3.5 pl-11 outline-none focus:ring-2 focus:ring-cyan-400 focus:bg-white transition-all duration-300 placeholder:text-gray-400 text-gray-700 font-medium";
  const labelClass = "block text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1.5 ml-1";
  const buttonClass = "w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold py-3.5 rounded-xl shadow-lg shadow-cyan-200 transition transform hover:-translate-y-0.5 active:scale-95 duration-200 flex items-center justify-center gap-2";

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#f8fafc] p-4 relative overflow-hidden">
      {/* Dynamic Background */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cyan-200/30 rounded-full blur-[100px] animate-pulse"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-200/30 rounded-full blur-[100px] animate-pulse delay-1000"></div>
        <div className="absolute top-[40%] left-[40%] w-[20%] h-[20%] bg-purple-200/20 rounded-full blur-[80px] animate-pulse delay-2000"></div>
      </div>

      {/* --- EMAIL SUCCESS VIEW --- */}
      {view === 'EMAIL_SENT' && (
        <div className={glassCardClass}>
          <div className="flex flex-col items-center text-center">
            <div className="w-20 h-20 bg-green-100/50 rounded-full flex items-center justify-center mb-6 ring-4 ring-green-50 animate-[bounce_1s_infinite]">
              <Mail className="w-10 h-10 text-green-600" />
            </div>
            <h2 className="text-2xl font-black text-gray-800 mb-2">Check Your Inbox!</h2>
            <p className="text-gray-500 mb-6 text-sm">
              We've sent your credentials to <span className="font-bold text-gray-800">{regEmail}</span>
            </p>
            <button
              onClick={() => { setLoginId(generatedId || ''); setGeneratedId(null); setView('LOGIN'); }}
              className={buttonClass}
            >
              Login Now
            </button>
          </div>
        </div>
      )}

      {/* --- LOGIN VIEW --- */}
      {view === 'LOGIN' && (
        <div className={glassCardClass}>
          {/* Logo Header */}
          <div className="flex flex-col items-center mb-8 pt-2">
            <Logo className="mb-6 scale-110" />

            {/* Toggle Switch */}
            <div className="flex bg-gray-100/80 p-1.5 rounded-xl w-full max-w-[280px] relative">
              <button
                onClick={() => { setIsAdminLogin(false); setLoginId(''); setLoginPass(''); setError(''); }}
                className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-lg transition-all duration-300 z-10 ${!isAdminLogin ? 'text-cyan-700' : 'text-gray-400 hover:text-gray-600'}`}
              >
                <UserIcon className="w-3.5 h-3.5" /> Employee
              </button>
              <button
                onClick={() => { setIsAdminLogin(true); setLoginName(''); setLoginPass(''); setError(''); }}
                className={`flex-1 flex items-center justify-center gap-2 py-2 text-xs font-bold rounded-lg transition-all duration-300 z-10 ${isAdminLogin ? 'text-blue-700' : 'text-gray-400 hover:text-gray-600'}`}
              >
                <ShieldCheck className="w-3.5 h-3.5" /> Mentor
              </button>

              {/* Sliding Background */}
              <div className={`absolute top-1.5 bottom-1.5 w-[calc(50%-6px)] bg-white rounded-lg shadow-sm transition-all duration-300 ease-spring ${isAdminLogin ? 'translate-x-[calc(100%+6px)]' : 'translate-x-0'}`}></div>
            </div>
          </div>

          {isAdminLogin ? (
            <form onSubmit={handleAdminLogin} className="space-y-5 animate-fade-in">
              <div>
                <label className={labelClass}>Mentor Name</label>
                <div className="relative group">
                  <ShieldCheck className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400 group-focus-within:text-blue-500 transition-colors" />
                  <input type="text" value={loginName} onChange={(e) => setLoginName(e.target.value)} className={inputClass} placeholder="Enter your name" required />
                </div>
              </div>
              <div>
                <label className={labelClass}>Secure PIN</label>
                <div className="relative group">
                  <KeyRound className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400 group-focus-within:text-blue-500 transition-colors" />
                  <input type="password" value={loginPass} onChange={(e) => setLoginPass(e.target.value.replace(/\D/g, '').slice(0, 4))} className={`${inputClass} tracking-[0.5em] font-mono text-center pl-12`} placeholder="••••" required />
                </div>
              </div>
              {error && <div className="text-red-500 text-xs text-center bg-red-50/50 p-2.5 rounded-lg font-bold border border-red-100">{error}</div>}
              <button type="submit" className={buttonClass}>Access Dashboard</button>
            </form>
          ) : (
            <form onSubmit={handleEmployeeLogin} className="space-y-5 animate-fade-in">
              <div>
                <label className={labelClass}>Employee ID</label>
                <div className="relative group">
                  <UserIcon className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400 group-focus-within:text-cyan-500 transition-colors" />
                  <input type="text" value={loginId} onChange={(e) => setLoginId(e.target.value)} className={inputClass} placeholder="e.g. ADZ-INT-1234" required />
                </div>
              </div>
              <div>
                <label className={labelClass}>Password</label>
                <div className="relative group">
                  <Lock className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400 group-focus-within:text-cyan-500 transition-colors" />
                  <input type="password" value={loginPass} onChange={(e) => setLoginPass(e.target.value)} className={inputClass} placeholder="••••••••" required />
                </div>
                <div className="text-right mt-2">
                  <button type="button" onClick={() => setView('FORGOT')} className="text-[11px] text-cyan-600 hover:text-cyan-800 font-bold transition">Forgot password?</button>
                </div>
              </div>
              {error && <div className="text-red-500 text-xs text-center bg-red-50/50 p-2.5 rounded-lg font-bold border border-red-100">{error}</div>}
              <button type="submit" className={buttonClass}>Secure Login</button>
            </form>
          )}

          {!isAdminLogin && (
            <div className="mt-8 text-center">
              <p className="text-gray-400 text-xs font-medium">New Team Member?</p>
              <button onClick={() => { setView('REGISTER'); setError(''); }} className="mt-1 text-cyan-600 hover:text-cyan-800 text-sm font-bold transition">
                Create Your Account
              </button>
            </div>
          )}
        </div>
      )}

      {/* --- REGISTER VIEW --- */}
      {view === 'REGISTER' && (
        <div className={`${glassCardClass} max-w-xl`}>
          {isRegistering && (
            <div className="absolute inset-0 bg-white/90 backdrop-blur-sm z-50 flex flex-col items-center justify-center">
              <Loader2 className="w-12 h-12 text-cyan-500 animate-spin mb-4" />
              <p className="text-gray-800 font-bold">Creating Secure Profile...</p>
            </div>
          )}

          <div className="flex items-center mb-6">
            <button onClick={() => setView('LOGIN')} className="p-2 hover:bg-gray-100 rounded-full transition mr-4 -ml-2 text-gray-500">
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h2 className="text-2xl font-black text-gray-800">Join the Team</h2>
          </div>

          <form onSubmit={handleRegister} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Full Name</label>
                <input type="text" value={regName} onChange={e => setRegName(e.target.value)} className={inputClass.replace('pl-11', 'pl-4')} placeholder="John Doe" required />
              </div>
              <div>
                <label className={labelClass}>Phone</label>
                <input type="tel" value={regPhone} onChange={e => setRegPhone(e.target.value)} className={inputClass.replace('pl-11', 'pl-4')} placeholder="9876543210" required />
              </div>
            </div>
            <div>
              <label className={labelClass}>Email Address</label>
              <input type="email" value={regEmail} onChange={e => setRegEmail(e.target.value)} className={inputClass.replace('pl-11', 'pl-4')} placeholder="john@example.com" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelClass}>Password</label>
                <input type="password" value={regPass} onChange={e => setRegPass(e.target.value)} className={inputClass.replace('pl-11', 'pl-4')} placeholder="Create pass" required />
              </div>
              <div>
                <label className={labelClass}>Confirm</label>
                <input type="password" value={regConfirmPass} onChange={e => setRegConfirmPass(e.target.value)} className={inputClass.replace('pl-11', 'pl-4')} placeholder="Confirm pass" required />
              </div>
            </div>
            <div>
              <label className={labelClass}>Role</label>
              <select value={regRole} onChange={e => setRegRole(e.target.value as Role)} className={`${inputClass.replace('pl-11', 'pl-4')} bg-white`}>
                {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
              </select>
            </div>
            {regRole === Role.INTERN && (
              <div className="animate-fade-in">
                <label className={labelClass}>Department</label>
                <select value={regDept} onChange={e => setRegDept(e.target.value as Department)} className={`${inputClass.replace('pl-11', 'pl-4')} bg-white`}>
                  {DEPARTMENTS.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
                </select>
              </div>
            )}
            {error && <div className="text-red-500 text-xs bg-red-50 p-3 rounded-lg font-bold">{error}</div>}
            <button type="submit" className={buttonClass}>Create Account</button>
          </form>
        </div>
      )}

      {/* --- FORGOT PASSWORD --- */}
      {view === 'FORGOT' && (
        <div className={glassCardClass}>
          <div className="text-center">
            <h2 className="text-2xl font-black text-gray-800 mb-2">Reset Password</h2>
            <p className="text-gray-500 mb-6 text-sm">Enter your email for instructions.</p>
            <form onSubmit={handleForgot} className="space-y-4 text-left">
              <label className={labelClass}>Email Address</label>
              <input type="email" className={inputClass.replace('pl-11', 'pl-4')} required />
              <button type="submit" className={buttonClass}>Send Link</button>
              <button type="button" onClick={() => setView('LOGIN')} className="w-full text-center text-xs text-gray-400 hover:text-gray-600 mt-4 transition">Back to Login</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};