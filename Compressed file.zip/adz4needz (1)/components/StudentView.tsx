import React, { useState, useEffect } from 'react';
import { User, Task, Role, ClassSession, StoredFile } from '../types';
import { getTasks, getTodayAttendance, markAttendance, addSubmission, getSubmissions, getClassSessions, readFileAsBase64 } from '../services/db';
import { Clock, CheckCircle, Upload, Send, File, X, Paperclip, Download, AlertTriangle, BookOpen } from 'lucide-react';

interface StudentViewProps {
    user: User;
}

export const StudentView: React.FC<StudentViewProps> = ({ user }) => {
    const [tasks, setTasks] = useState<Task[]>([]);
    const [attendance, setAttendance] = useState(getTodayAttendance(user.id));
    const [submissionMap, setSubmissionMap] = useState<Record<string, boolean>>({});
    const [classSessions, setClassSessions] = useState<ClassSession[]>([]);

    // Submission inputs
    const [textAnswers, setTextAnswers] = useState<Record<string, string>>({});
    const [taskFiles, setTaskFiles] = useState<Record<string, StoredFile[]>>({}); // Store file objects

    const today = new Date().toISOString().split('T')[0];

    useEffect(() => {
        // Filter tasks for this user
        const allTasks = getTasks();
        const myTasks = allTasks.filter(t => {
            const dateMatch = t.date === today;
            const roleMatch = !t.assignedToRole || t.assignedToRole === user.role;
            const deptMatch = !t.assignedToDepartment || t.assignedToDepartment === user.department;
            return dateMatch && roleMatch && deptMatch;
        });
        setTasks(myTasks);

        // Get Today's Class Notes - Filtered by Date AND Department
        const allSessions = getClassSessions();
        const todaySessions = allSessions.filter(s =>
            s.date === today &&
            s.department === user.department
        );
        setClassSessions(todaySessions);

        // Check existing submissions
        const mySubs = getSubmissions().filter(s => s.userId === user.id);
        const subMap: Record<string, boolean> = {};
        mySubs.forEach(s => subMap[s.taskId] = true);
        setSubmissionMap(subMap);
    }, [user.id, user.role, user.department, today]);

    const formatTime = (isoString: string) => {
        if (!isoString) return '';
        if (!isoString.includes('T') && isoString.includes(':')) return isoString;
        try {
            return new Date(isoString).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
        } catch {
            return isoString;
        }
    };

    const handleAttendance = () => {
        if (attendance) return;

        const now = new Date();
        // Logic removed as per request. Attendance is now always PRESENT regardless of time.

        let status: 'PRESENT' | 'LATE' = 'PRESENT';


        const newAtt = {
            id: `ATT-${Date.now()}`,
            userId: user.id,
            date: today,
            clockInTime: now.toISOString(), // Store exact ISO time for data precision
            status
        };

        markAttendance(newAtt);
        setAttendance(newAtt);
    };

    const handleSubmit = (taskId: string) => {
        const content = textAnswers[taskId] || '';
        const files = taskFiles[taskId] || [];

        if (!content.trim() && files.length === 0) {
            alert("Please provide either a text description or upload files to submit your work.");
            return;
        }

        const now = new Date();
        const deadlineHour = 18; // 6:30 PM
        const deadlineMinute = 30;
        const currentMinutes = now.getHours() * 60 + now.getMinutes();
        const deadlineMinutes = deadlineHour * 60 + deadlineMinute;

        const status = currentMinutes > deadlineMinutes ? 'LATE' : 'SUBMITTED';

        addSubmission({
            id: `SUB-${Date.now()}`,
            taskId,
            userId: user.id,
            content: content,
            files: files, // Save the actual file objects
            submittedAt: new Date().toISOString(),
            status
        });

        setSubmissionMap(prev => ({ ...prev, [taskId]: true }));
    };

    const handleFileChange = async (taskId: string, e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            const rawFiles: File[] = Array.from(e.target.files);
            // 2MB warning per file
            if (rawFiles.some(f => f.size > 2 * 1024 * 1024)) {
                alert("Warning: Large files detected. Browser storage is limited.");
            }

            try {
                const processed = await Promise.all(rawFiles.map(readFileAsBase64));
                setTaskFiles(prev => {
                    const existing = prev[taskId] || [];
                    return { ...prev, [taskId]: [...existing, ...processed] };
                });
            } catch (err) {
                console.error(err);
                alert("Error processing file upload.");
            }
        }
    };

    const removeFile = (taskId: string, fileNameToRemove: string) => {
        setTaskFiles(prev => {
            const current = prev[taskId] || [];
            return { ...prev, [taskId]: current.filter(f => f.name !== fileNameToRemove) };
        });
    };

    const handleDownload = (file: StoredFile | string) => {
        if (typeof file === 'string') {
            alert("Legacy file format: " + file + "\nCannot open file content.");
            return;
        }
        const link = document.createElement("a");
        link.href = file.content;
        link.download = file.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="space-y-8 animate-fade-in pb-12">
            {/* Welcome & Attendance Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 text-white shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16"></div>
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/10 rounded-full blur-2xl -ml-10 -mb-10"></div>

                <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-6">
                    <div>
                        <h2 className="text-3xl font-bold tracking-tight mb-1">Hello, {user.fullName}</h2>
                        <p className="opacity-90 flex items-center gap-2 text-sm font-medium">
                            {user.role === Role.TELECALLER ? 'Telecaller' : user.role === Role.EMPLOYEE ? 'Full-Time Employee' : `${user.department} Intern`}
                            <span className="w-1 h-1 bg-white rounded-full"></span>
                            ID: <span className="font-mono bg-white/20 px-1 rounded">{user.id}</span>
                        </p>
                    </div>

                    <div className="bg-white/15 p-4 rounded-xl backdrop-blur-md text-center min-w-[200px] border border-white/20 shadow-inner">
                        <p className="text-xs uppercase font-bold opacity-80 mb-2 tracking-wider">Today's Attendance</p>
                        {attendance ? (
                            <div className="flex flex-col items-center animate-fade-in">
                                <span className={`text-2xl font-bold mb-1 ${attendance.status === 'LATE' ? 'text-yellow-300' : 'text-green-300'}`}>
                                    {attendance.status}
                                </span>
                                <span className="text-xs opacity-75">Clocked in at {formatTime(attendance.clockInTime)}</span>
                            </div>
                        ) : (
                            <button
                                onClick={handleAttendance}
                                className="w-full bg-white text-blue-700 font-bold py-2.5 px-4 rounded-lg shadow-lg hover:bg-blue-50 transition transform hover:-translate-y-0.5"
                            >
                                Mark Present
                            </button>
                        )}
                    </div>
                </div>
            </div>

            {/* Warning/Info Banner */}


            {/* --- Class Notes Section --- */}
            {classSessions.length > 0 && (
                <div className="bg-gradient-to-br from-purple-50 to-white rounded-2xl p-6 shadow-sm border border-purple-100 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-purple-100/50 rounded-bl-full z-0"></div>
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-6 border-b border-purple-100 pb-4">
                            <div className="bg-purple-100 p-2 rounded-lg">
                                <BookOpen className="w-5 h-5 text-purple-600" />
                            </div>
                            <h3 className="text-xl font-bold text-gray-800">
                                Today's Class Notes & Revisions
                            </h3>
                        </div>

                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                            {classSessions.map(session => (
                                <div key={session.id} className="bg-white border border-gray-200 rounded-xl p-5 hover:shadow-lg transition-all duration-300 group">
                                    <div className="flex justify-between items-start mb-2">
                                        <h4 className="font-bold text-gray-800 text-lg group-hover:text-purple-700 transition-colors">{session.topic}</h4>
                                    </div>
                                    <p className="text-sm text-gray-600 mb-4 leading-relaxed">{session.description || "No description provided."}</p>

                                    {(session.attachments || []).length > 0 && (
                                        <div className="space-y-2 mt-auto">
                                            <p className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Attachments</p>
                                            <div className="flex flex-col gap-2">
                                                {(session.attachments || []).map((file, i) => (
                                                    <button
                                                        key={i}
                                                        onClick={() => handleDownload(file)}
                                                        className="flex items-center justify-between gap-2 text-xs bg-purple-50 p-2.5 rounded-lg border border-purple-100 text-purple-700 font-medium hover:bg-purple-100 hover:border-purple-200 transition-colors w-full text-left"
                                                    >
                                                        <div className="flex items-center gap-2 truncate">
                                                            <File className="w-3.5 h-3.5 flex-shrink-0" />
                                                            <span className="truncate">{typeof file === 'string' ? file : file.name}</span>
                                                        </div>
                                                        <Download className="w-3.5 h-3.5 flex-shrink-0 opacity-50" />
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Daily Tasks Section */}
            <div>
                <h3 className="text-xl font-bold text-gray-800 mb-5 flex items-center gap-2">
                    <CheckCircle className="w-6 h-6 text-blue-600" />
                    Your Tasks for Today <span className="text-gray-400 text-sm font-normal">({today})</span>
                </h3>

                {tasks.length === 0 ? (
                    <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-gray-300">
                        <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-3">
                            <Clock className="w-8 h-8 text-gray-300" />
                        </div>
                        <p className="text-gray-500 font-medium">No tasks assigned yet.</p>
                        <p className="text-sm text-gray-400 mt-1">Check back later or contact your mentor.</p>
                    </div>
                ) : (
                    <div className="grid gap-6">
                        {tasks.map(task => {
                            const isSubmitted = submissionMap[task.id];
                            const currentFiles = taskFiles[task.id] || [];

                            return (
                                <div key={task.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden transition hover:shadow-md">
                                    <div className="p-6 border-b border-gray-50">
                                        <div className="flex justify-between items-start">
                                            <div className="flex-1 pr-4">
                                                <h4 className="text-lg font-bold text-gray-800">{task.title}</h4>
                                                <p className="text-gray-600 mt-3 leading-relaxed">{task.description}</p>

                                                {/* Reference Attachments Display */}
                                                {task.attachments && task.attachments.length > 0 && (
                                                    <div className="mt-4 p-4 bg-blue-50/50 rounded-xl border border-blue-100 inline-block w-full sm:w-auto">
                                                        <h5 className="text-[10px] font-bold text-blue-800 uppercase mb-2 flex items-center gap-1 tracking-wider">
                                                            <Paperclip className="w-3 h-3" /> Reference Files
                                                        </h5>
                                                        <div className="flex flex-wrap gap-2">
                                                            {task.attachments.map((file, i) => (
                                                                <button
                                                                    key={i}
                                                                    onClick={() => handleDownload(file)}
                                                                    className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-blue-200 text-xs font-medium text-blue-600 hover:shadow-sm hover:border-blue-300 transition"
                                                                >
                                                                    <Download className="w-3 h-3" />
                                                                    {typeof file === 'string' ? file : file.name}
                                                                </button>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                            <span className={`flex-shrink-0 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide ${isSubmitted ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                                                {isSubmitted ? 'Submitted' : 'Pending'}
                                            </span>
                                        </div>
                                    </div>

                                    {!isSubmitted && (
                                        <div className="p-6 bg-gray-50/50 space-y-5">
                                            <h5 className="text-sm font-bold text-gray-700 border-b border-gray-200 pb-2">Submit Your Work</h5>

                                            {/* 1. Text Input */}
                                            <div>
                                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">
                                                    Work Description / Answer
                                                </label>
                                                <textarea
                                                    className="w-full border border-gray-300 rounded-xl p-3 h-28 focus:ring-2 focus:ring-blue-500 outline-none text-sm transition"
                                                    placeholder="Type your detailed response, calls made, or summary here..."
                                                    value={textAnswers[task.id] || ''}
                                                    onChange={e => setTextAnswers(prev => ({ ...prev, [task.id]: e.target.value }))}
                                                />
                                            </div>

                                            {/* 2. File Upload */}
                                            <div>
                                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">
                                                    Attach Files
                                                </label>
                                                <div className="flex flex-col gap-3">
                                                    <label className="cursor-pointer flex flex-col items-center justify-center gap-2 px-4 py-6 bg-white border-2 border-dashed border-gray-300 rounded-xl hover:bg-blue-50 hover:border-blue-400 transition group">
                                                        <div className="bg-gray-100 p-3 rounded-full group-hover:bg-blue-100 transition">
                                                            <Upload className="w-5 h-5 text-gray-400 group-hover:text-blue-500" />
                                                        </div>
                                                        <div className="text-center">
                                                            <span className="text-sm font-medium text-gray-600 group-hover:text-blue-600">Click to Upload Files</span>
                                                            <p className="text-xs text-gray-400 mt-1">Supports All File Types (PDF, Images, Docs, JSON, MD, etc.)</p>
                                                        </div>
                                                        <input
                                                            type="file"
                                                            multiple
                                                            // Removed accept attribute
                                                            className="hidden"
                                                            onChange={(e) => handleFileChange(task.id, e)}
                                                        />
                                                    </label>

                                                    {/* File List */}
                                                    {currentFiles.length > 0 && (
                                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                                            {currentFiles.map((file, idx) => (
                                                                <div key={idx} className="flex items-center justify-between text-xs bg-white px-3 py-2 rounded-lg border border-gray-200 shadow-sm">
                                                                    <div className="flex items-center gap-2 text-gray-700 truncate">
                                                                        <File className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
                                                                        <span className="truncate">{file.name}</span>
                                                                    </div>
                                                                    <button
                                                                        onClick={() => removeFile(task.id, file.name)}
                                                                        className="text-gray-400 hover:text-red-500 transition p-1"
                                                                    >
                                                                        <X className="w-3.5 h-3.5" />
                                                                    </button>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    )}
                                                </div>
                                            </div>

                                            <button
                                                onClick={() => handleSubmit(task.id)}
                                                className="w-full flex justify-center items-center gap-2 bg-blue-600 text-white px-5 py-3.5 rounded-xl hover:bg-blue-700 transition font-bold shadow-lg shadow-blue-200 mt-2"
                                            >
                                                <Send className="w-4 h-4" /> Submit Work
                                            </button>
                                        </div>
                                    )}

                                    {isSubmitted && (
                                        <div className="p-4 bg-green-50 text-green-800 text-sm font-medium flex items-center gap-2 border-t border-green-100">
                                            <CheckCircle className="w-5 h-5 text-green-600" />
                                            Great job! You have submitted this task.
                                        </div>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};